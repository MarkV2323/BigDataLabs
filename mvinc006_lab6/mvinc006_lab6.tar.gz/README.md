# Lab 6

## Student information

* Full name: Mark Alan Vincent II
* E-mail: mvinc006@ucr.edu
* UCR NetID: mvinc006
* Student ID: 862195494

## Answers

* (Q1) What are these two arguments?  
The first argument is command, which specifics the transition to use, such as code-filter or count-all,
the rest being located in the match statement. The second argument is for the input file path.  


* (Q2) If you do this bonus part, copy and paste your code in the README file as an answer to this question.  


* (Q3) What is the type of the attributes `time` and `bytes` this time? Why?  
`time` and `bytes` are both considered strings because we commented out the line that allows
the reader to infer the schema. Now it just considers all types to be strings.  


* (Q4) If you do this bonus part, copy and paste your code in the README file as an aswer to this question.  
