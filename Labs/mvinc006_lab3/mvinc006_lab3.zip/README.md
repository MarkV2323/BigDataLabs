# CS167 Lab 3

## Student Information:
* Name: Mark Alan Vincent II
* Email: mvinc006@ucr.edu
* NID: mvinc006
* SID: 862195494

## Answers:
(Q1) Which of the following is the right way to call the ``IsEven`` function?    
new IsEven().apply(5)

(Q2) Did the program compile?   
No it did not compile.  

(Q3) If it does not work, what is the error message you get?  
This is the error I got,  
``[ERROR] /Users/vincentmark/workspace/mvinc006_lab3
/src/main/java/edu/ucr/cs/cs167/mvinc006/App.java:
[110,63] local variables referenced from a lambda expression must be final or effectively final``

