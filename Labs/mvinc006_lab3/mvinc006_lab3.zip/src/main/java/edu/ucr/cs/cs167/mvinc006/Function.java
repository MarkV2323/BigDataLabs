package edu.ucr.cs.cs167.mvinc006;

//public interface Function<T, T1> {
//    T1 apply(T x);
//
//    Function<T, T1> compose(Function<T, T1> filter);
//}
